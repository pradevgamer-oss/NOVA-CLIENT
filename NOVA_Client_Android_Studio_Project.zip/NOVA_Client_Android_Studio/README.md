# NOVA Client — Android Studio starter

This is the first installable-app project foundation for NOVA Client.

## What works in this starter
- Native Android launcher dashboard
- Launches the installed Minecraft Bedrock app (`com.mojang.minecraftpe`)
- Module Center with locally saved toggle preferences
- File picker for `.mcpack` / `.mcaddon` files and hands the selected file to Android's handler

## Important limitations
The module switches are configuration placeholders in v0.1.0. They do not inject code into Minecraft, draw overlays over gameplay, or change Bedrock internals. A normal Android launcher cannot safely promise arbitrary client-side injection. Real in-game functionality must be implemented through supported Bedrock resource packs, behavior packs, scripting APIs, or documented Android capabilities.

## Build an APK
1. Install Android Studio (a current stable version) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync and install the required Android Gradle Plugin / Kotlin plugin.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

Minimum Android version: Android 6.0 (API 23). Target SDK: 35.
