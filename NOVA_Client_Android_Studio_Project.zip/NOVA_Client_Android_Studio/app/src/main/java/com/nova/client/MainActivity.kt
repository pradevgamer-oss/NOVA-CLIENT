package com.nova.client

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("nova_modules", MODE_PRIVATE) }
    private val bg = Color.rgb(10, 13, 24)
    private val panel = Color.rgb(22, 28, 46)
    private val accent = Color.rgb(83, 155, 255)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String, subtitle: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        text(root, "NOVA CLIENT", 12, accent, true)
        text(root, title, 28, Color.WHITE, true)
        text(root, subtitle, 14, Color.LTGRAY, false)
        space(root, 18)
        root.addView(content)
        // content is intentionally the main vertical page body
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        text(body, "NOVA CLIENT", 13, accent, true)
        text(body, "Your game.\nYour setup.", 32, Color.WHITE, true)
        text(body, "A customizable companion launcher for Minecraft Bedrock on Android.", 15, Color.LTGRAY, false)
        space(body, 24)
        card(body, "MINECRAFT BEDROCK", "Launch the installed Minecraft app") {
            val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
            if (intent != null) startActivity(intent)
            else toast("Minecraft Bedrock was not found on this device.")
        }
        card(body, "MODULE CENTER", "Configure available NOVA companion features") { showModules() }
        card(body, "RESOURCE PACK IMPORT", "Choose a .mcpack or .mcaddon file to open with Minecraft") { choosePack() }
        card(body, "CLIENT PROFILES", "Save module preferences on this device") {
            toast("Your module settings are saved locally in this first build.")
        }
        space(body, 14)
        text(body, "BUILD 0.1.0 • ANDROID", 11, Color.GRAY, true)
        text(body, "Note: modules in this starter build are launcher-side settings. They do not inject code into Minecraft or create in-game overlays.", 12, Color.LTGRAY, false)
    }

    private fun showModules() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        text(body, "NOVA CLIENT", 13, accent, true)
        text(body, "Module Center", 28, Color.WHITE, true)
        text(body, "Choose which companion tools you want enabled.", 14, Color.LTGRAY, false)
        space(body, 18)

        val groups = linkedMapOf(
            "HUD & MONITORING" to listOf("FPS Counter", "CPS Counter", "Coordinates Widget", "Session Timer"),
            "VISUAL CUSTOMIZATION" to listOf("Crosshair Preset", "HUD Theme", "Color Profile"),
            "GAMEPLAY UTILITIES" to listOf("Quick Launch", "Resource Pack Shortcut")
        )
        groups.forEach { (heading, names) ->
            text(body, heading, 12, accent, true)
            names.forEach { name ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14), dp(9), dp(12), dp(9))
                    background = rounded(panel, 14)
                }
                val label = TextView(this).apply {
                    text = name
                    textSize = 15f
                    setTextColor(Color.WHITE)
                }
                row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
                val toggle = Switch(this).apply {
                    isChecked = prefs.getBoolean(name, false)
                    setOnCheckedChangeListener { _, checked ->
                        prefs.edit().putBoolean(name, checked).apply()
                    }
                }
                row.addView(toggle)
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.bottomMargin = dp(8)
                body.addView(row, lp)
            }
            space(body, 10)
        }
        text(body, "These switches currently store preferences only. Actual in-game modules require supported Bedrock add-on/resource-pack APIs; arbitrary client injection is not provided.", 12, Color.LTGRAY, false)
        val back = Button(this).apply { text = "BACK TO HOME"; setOnClickListener { showHome() } }
        body.addView(back)
    }

    private fun choosePack() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream",
                "application/zip",
                "application/x-zip-compressed"
            ))
        }
        try { startActivityForResult(intent, 42) }
        catch (_: Exception) { toast("Could not open file picker.") }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/octet-stream")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try { startActivity(view) }
            catch (_: Exception) { toast("No app could open this pack. Try opening it from your file manager.") }
        }
    }

    private fun card(parent: LinearLayout, title: String, desc: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(panel, 18)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        text(box, title, 15, Color.WHITE, true)
        text(box, desc, 12, Color.LTGRAY, false)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(12)
        parent.addView(box, lp)
    }

    private fun text(parent: LinearLayout, value: String, size: Int, color: Int, bold: Boolean) {
        val t = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        parent.addView(t)
    }

    private fun space(parent: LinearLayout, h: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
